iqoptionapi.ws.chanels package
==============================

Submodules
----------

iqoptionapi.ws.chanels.base module
----------------------------------

.. automodule:: iqoptionapi.ws.chanels.base
    :members:
    :undoc-members:
    :show-inheritance:

iqoptionapi.ws.chanels.buyback module
-------------------------------------

.. automodule:: iqoptionapi.ws.chanels.buyback
    :members:
    :undoc-members:
    :show-inheritance:

iqoptionapi.ws.chanels.buyv2 module
-----------------------------------

.. automodule:: iqoptionapi.ws.chanels.buyv2
    :members:
    :undoc-members:
    :show-inheritance:

iqoptionapi.ws.chanels.candles module
-------------------------------------

.. automodule:: iqoptionapi.ws.chanels.candles
    :members:
    :undoc-members:
    :show-inheritance:

iqoptionapi.ws.chanels.setactives module
----------------------------------------

.. automodule:: iqoptionapi.ws.chanels.setactives
    :members:
    :undoc-members:
    :show-inheritance:

iqoptionapi.ws.chanels.ssid module
----------------------------------

.. automodule:: iqoptionapi.ws.chanels.ssid
    :members:
    :undoc-members:
    :show-inheritance:

iqoptionapi.ws.chanels.subscribe module
---------------------------------------

.. automodule:: iqoptionapi.ws.chanels.subscribe
    :members:
    :undoc-members:
    :show-inheritance:

iqoptionapi.ws.chanels.unsubscribe module
-----------------------------------------

.. automodule:: iqoptionapi.ws.chanels.unsubscribe
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: iqoptionapi.ws.chanels
    :members:
    :undoc-members:
    :show-inheritance:
